import whisper
from deep_translator import GoogleTranslator
from gtts import gTTS
import os


class SpeechProcessingModel:
    def __init__(self, model_name):
        self.model = whisper.load_model(model_name)

    def load_audio(self, audio_path):
        audio = whisper.load_audio(audio_path)
        audio = whisper.pad_or_trim(audio)
        mel = whisper.log_mel_spectrogram(audio).to(self.model.device)

        return audio, mel

    def detect_language(self, mel):
        _, probs = self.model.detect_language(mel)
        detected_language = max(probs, key=probs.get)
        return detected_language

    def decode_audio(self, audio, mel):
        mel = whisper.log_mel_spectrogram(audio).to(self.model.device)
        options = whisper.DecodingOptions(fp16=False)
        result = whisper.decode(self.model, mel, options)
        return result.text

    def translate(self, text, target):
        translated = GoogleTranslator(source="auto", target=target).translate(text)
        return translated

    def text_to_speech(self, text, language="en", output_path="output.mp3"):
        tts = gTTS(text=text, lang=language, slow=False, tld="us")
        tts.save(output_path)


if __name__ == "__main__":
    audio_path = input("Enter the path to the audio file: ")

    # 'chinese (simplified)': 'zh-CN','french': 'fr','arabic': 'ar','urdu': 'ur','german': 'de','japanese': 'ja'
    target_language = input(
        "Enter the target language (e.g., chinese (simplified)': 'zh-CN','french': 'fr','arabic': 'ar','urdu': 'ur','german': 'de','japanese': 'ja'): "
    )
    model_instance = SpeechProcessingModel("base")

    loaded_audio, mel = model_instance.load_audio(audio_path)
    detected_language = model_instance.detect_language(mel=mel)
    print(f"Detected language: {detected_language}")

    recognized_text = model_instance.decode_audio(loaded_audio, mel=mel)
    print(f"Recognized text: {recognized_text}")

    translated_text = model_instance.translate(recognized_text, target=target_language)
    print(f"Translated text: {translated_text}")
    model_instance.text_to_speech(translated_text, language=target_language)
